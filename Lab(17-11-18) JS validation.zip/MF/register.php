<html>
<head>
	<title>Register</title>
	
	
	
	<script>
	
	
    function validateForm() {
	var i = document.forms["myForm"]["aiubid"].value;
	var n = document.forms["myForm"]["fname"].value;
	var e = document.forms["myForm"]["email"].value;
	var m = document.forms["myForm"]["phone"].value;
	var p = document.forms["myForm"]["password"].value;
    var cp = document.forms["myForm"]["Conpassword"].value;
	
	sidregex =/[0-9]{2}-[0-9]{5}-[1-3]{1}/
	sid = i.match(sidregex);
	
	if (i != sid)
	{
        alert("Please provide ID in the format ##-#####-#.(numbers only)white spaces are not allowed");
        document.myForm.aiubid.focus();
        return false;
	}
	
	fnameregex =/^[a-zA-Z ]+$/
	fname = n.match(fnameregex);
	
	
	if (n == "" || n != fname)
	{
        alert("Your full name is not valid. Only characters A-Z, a-z are  acceptable.");
        document.myForm.fname.focus();
        return false;
	}
	if (e == "")
	{
        alert("Email is required");
        document.myForm.email.focus();
        return false;
	}
	
	phnregex =/[0-9]{11}/
	phn = m.match(phnregex);
	
	if (m != phn)
	{
        alert("Please provide your valid phone number with 11 digit. white spaces are not allowed");
        document.myForm.phone.focus();
        return false;
	}
	
	if (p == "")
	{
        alert("Enter a password");
        document.myForm.password.focus();
        return false;
	}
	
	if (cp != p)
	{
        alert("Password don't match");
        document.myForm.Conpassword.focus();
        return false;
	}
	if (cp == p)
	{
        alert("Registration Successful");
        document.myForm.Conpassword.focus();
		qwertyuiop[]asdfghjkl;'\/.,return false;
        
	}
	

    

	
}
</script>
             			 
	
</head>

<body>
<br>


	<center><h2>New User Registration</h2><hr></center>
	<form name="myForm" onsubmit="return validateForm()" method="POST" action="">
		<table>
            <tr>
                <td>AIUB ID</td>
                <td><input type="text" name="aiubid"  >
				
				</td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td><input type="text" name="fname" > 
				</td>
            </tr>
            <tr>
				<td>Email</td>
				<td><input type="email" name="email"  value="" >
				
				</td>
			</tr>
            <tr>
                <td>Phone Number</td>
                <td><input type="text" name="phone"  value="" >
				
				</td>
            </tr>
			<tr> 
				<td>Password</td >
				<td><input type="password" name="password"  value="" ></td>
			</tr>
			<tr> 
				<td>Confirm Password</td >
				<td><input type="password" name="Conpassword"  value="" ></td>
			</tr> 
			
			<tr>
            <td colspan="2"><br></td>
            </tr>
            <tr> 
			     
				<td> <input type="submit" value="Register"></td>
				
			</tr>
			<tr>
            <td colspan="2"><br></td>
            </tr>
			
			
		</table>
		
	</form>

<!--	<button onclick="window.location.href='/MF/view.php'">View Details</button>  -->



</body>
</html>
