<html>
<head>
	<title>Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
  	<script src="js/bootstrap.min.js"></script>
	<style>
                .error {color: #FF0000;}
               </style>
             			 
	
</head>

<body class="container">
<br>
<a href="index.php"><span class="btn btn-primary">Home</span></a> <br />
<?php
include("config.php");
//connect to db here

$nameErr = $emailErr = $idErr = $passErr = $phnErr = "";
$fullname = $email = $aiubid = $pass = $confirmpass= $phone = "";

if(isset($_POST['submit'])) {
	$aiubid = $_POST['aiubid'];
	$fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pass = $_POST['password'];
	$confirmpass = $_POST['confirmpass'];


	 if($pass == ""|| $aiubid == "" || $fullname == ""|| $email == "" || $phone == "") {
		
	   echo "All fields should be filled. Either one or many fields are empty.";
	  
	   
	}  
	
	if ($pass != "" && $aiubid != "" && $fullname != "" && $email != "" && $phone != "")
	{
	if (!preg_match("/[0-9]{2}-[0-9]{5}-[0-9]{1}$/",$aiubid)) 
	   {
         $idErr = "Invalid ID formate"; 
	   }
		else if (!preg_match("/^[a-zA-Z ]*$/",$fullname)) 
		 {
          $nameErr = "Only letters and white space allowed in fullname"; 
		 }
	       else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
			 {
              $emailErr = "Invalid email format"; 
		     }
		  else if (!preg_match("/^[0-9]{11}$/",$phone)) {
            $phnErr = "Invalid Phone No.(start from '0')"; 
            }
			else if($confirmpass!=$pass)
			{
			 $passErr ="Password don't match";
			}
	
	   else{
	   mysqli_query($conn,"INSERT INTO user(aiubid,fullname,email,phone,password) VALUES('$aiubid','$fullname','$email','$phone', md5('$confirmpass'))")
			or die("Could not execute the insert query.");
			
		echo "<hr><div class='alert alert-success'>Registration successfully done. Click Home for login Now</div>";
		echo "<br/><hr>";
	   }
	}	
	
	
} 
?>

	<center><h2>New User Registration</h2><hr></center>
	<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<table class="table table-striped table-bordered table-condensed">
            <tr>
                <td>AIUB ID</td>
                <td><input type="text" name="aiubid" class="form-control" value="<?php echo $aiubid;?>">
				<span class="error"> <?php echo $idErr;?></span>
				</td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td><input type="text" name="fullname" class="form-control" value="<?php echo $fullname;?>">
				    <span class="error"> <?php echo $nameErr;?></span>
				</td>
            </tr>
            <tr>
				<td>Email</td>
				<td><input type="email" name="email" class="form-control" value="<?php echo $email;?>">
				<span class="error"> <?php echo $emailErr;?></span>
				</td>
			</tr>
            <tr>
                <td>Phone Number</td>
                <td><input type="text" name="phone" class="form-control" value="<?php echo $phone;?>">
				<span class="error"> <?php echo $phnErr;?></span>
				</td>
            </tr>
			<tr> 
				<td>Password</td>
				<td><input type="password" name="password" class="form-control" value="<?php echo $pass;?>"></td>
			</tr>
			<tr> 
				<td>Confirm Password</td>
				<td><input type="password" name="confirmpass" class="form-control" value="<?php echo $confirmpass;?>">
				<span class="error"> <?php echo $passErr;?></span>
				</td>
			</tr>
			<tr>
            <td colspan="2"><br></td>
            </tr>
            <tr> 
				
				<td colspan="2"><input type="submit" class="btn btn-success btn-block btn-lg" name="submit" value="Register"></td>
			</tr>
		</table>
	</form>



</body>
</html>
