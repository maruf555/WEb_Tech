<html>
<head>
	<title>Register</title>
	
	<script>
    function validateForm() {
    var i = document.forms["myForm"]["aiubid"].value;;
	var n = document.forms["myForm"]["fname"].value;
	var e = document.forms["myForm"]["email"].value;;
	var m = document.forms["myForm"]["phone"].value;;
	var p = document.forms["myForm"]["password"].value;;
    
	gval = this.tormname.inputname.value;
	sidregex =/ [0-9]{2}-[0-9]{5}-[1-3]{1}/
	sid = sidregex.test(gval)
	
	
	
	
}
</script>
             			 
	
</head>

<body>
<br>



	<center><h2>New User Registration</h2><hr></center>
	<form name="myForm" onsubmit="return validateForm()" method="post" action="">
		<table>
            <tr>
                <td>AIUB ID</td>
                <td><input type="text" name="aiubid" required >
				
				</td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td><input type="text" name="fname" required>
				    <!--<input id="id1" type="number" min="100" max="300" required> -->
				</td>
            </tr>
            <tr>
				<td>Email</td>
				<td><input type="email" name="email"  value="" required>
				
				</td>
			</tr>
            <tr>
                <td>Phone Number</td>
                <td><input type="text" name="phone"  value="" required>
				
				</td>
            </tr>
			<tr> 
				<td>Password</td >
				<td><input type="password" name="password"  value="" required></td>
			</tr>
			<tr>
            <td colspan="2"><br></td>
            </tr>
            <tr> 
				<td> <input type="submit" value="Register"></td>
				
			</tr>
		</table>
		
	</form>

<button onclick="window.location.href='/MF/view.php'">View Details</button>

</body>
</html>
